#####
# Python Toolbox
##### Apache License 2.0

# Made by Amy Wengefeld

# 4-30-2019

# This Python Toolbox contains 3 tools. The tools are MultipleBufferTool, ClipTool, and the
# SplitbyAttributeTool. They are designed to be used in that order. The MultipleBufferTool
# takes a point SHP file of well water workshops in RI (i.e. venues) and buffers them by 5, 10, 15,
# 20, 150 miles. The output,Venues_MultipleRingBuffer_5, will be put into the input directory
# or GDB. Then the ClipTool clips, Venues_MultipleRingBuffer_5, to the RI_Boundary. The final tool,
# SplitbyAttributeTool, takes the previous output, Site_Buffer_clip, and splits the SHP file by
# their respective venues.

# starter script
# http://desktop.arcgis.com/en/arcmap/10.3/analyze/creating-tools/a-quick-tour-of-python-toolboxes.htm

import arcpy
arcpy.env.overwriteOutput = True
# creates the toolbox itself...MUST ALWAYS BE CALLED TOOLBOX
class Toolbox(object):
    def __init__(self):
        """Define the toolbox (the name of the toolbox is the name of the
        .pyt file)."""
        self.label = "Python Toolbox Final"
        self.alias = ""

        # List of tool classes associated with this toolbox
        self.tools = [MultipleBufferTool, ClipTool, SplitbyAttributeTool]

####################################MultipleBufferTool#############################################################

class MultipleBufferTool(object):
    def __init__(self):
        """Define the tool (tool name is the name of the class)."""
        self.label = "MultipleBufferTool"  # name of the tool
        self.description = "This tool takes a point SHP file of well water workshops in RI (i.e. venues) and buffers " \
                           "them by 5, 10, 15, 20, 150 miles. The output, Venues_MultipleRingBuffer_5, will be put into"\
                           "the input directory or GDB"
        # description or label of tool
        self.canRunInBackground = False  # background geoprocessing, you can do things while it is running
        # most the time it is true but false if you dont want other stuff running

    def getParameterInfo(self):
        """Define parameter definitions"""

        params = []

        # for buffer - parameter 0
        input_points = arcpy.Parameter(name="Venues",
                                       displayName="Venues",
                                       datatype="DEFeatureClass",
                                       parameterType="Required",  # Required|Optional|Derived
                                       direction="Input",  # Input|Output
                                       )

        params.append(input_points)


        #for buffer - parameter 1
        Directory = arcpy.Parameter(name="Input_Directory",
                                       displayName="Input Directory",
                                       datatype="DEWorkspace",
                                       parameterType="Required",  # Required|Optional|Derived
                                       direction="Input",  # Input|Output
                                       )

        params.append(Directory)

        return params

#Don't touch below
    def isLicensed(self):
            """Set whether tool is licensed to execute."""
            return True

    def updateParameters(self, parameters):
            """Modify the values and properties of parameters before internal
            validation is performed.  This method is called whenever a parameter
            has been changed."""  # can provide a warning if the wrong data
            return

    def updateMessages(self, parameters):
            """Modify the messages created by internal validation for each tool
            parameter.  This method is called after internal validation."""
            return
#Don't touch above

    def execute(self, parameters, messages):
        """The source code of the tool."""

        import os

        input_points = parameters[0].valueAsText
        Directory = parameters[1].valueAsText

        #Process: multiple ring buffer
        arcpy.MultipleRingBuffer_analysis(input_points, os.path.join(Directory, "Venues_MultipleRingBuffer_5"),
                                  [5, 10, 15, 20, 150], "miles", "distance", "NONE")


        return

######################################ClipTool#######################################################################

class ClipTool(object):
    def __init__(self):
         """Define the tool (tool name is the name of the class)."""
         self.label = "ClipTool"  # name of the tool
         self.description = "This tool takes the previously created,Venues_MultipleRingBuffer_5, and clips it" \
                               "to the Rhode Island Boundary (i.e. RI_Bound) "  # description or label of tool
         self.canRunInBackground = False  # background geoprocessing, you can do things while it is running
            # most the time it is true but false if you dont want other stuff running

    def getParameterInfo(self):
        """Define parameter definitions"""
        params2 = []

#for clip parameter 0
        input_SHP = arcpy.Parameter(name="MultipleRingBuffer_5_to_be_Clipped",
                                       displayName="Multiple Ring Buffer to be Clipped",
                                       datatype="DEFeatureClass",
                                       parameterType="Required",  # Required|Optional|Derived
                                       direction="Input",  # Input|Output
                                       )

        params2.append(input_SHP)
#for clip parameter 1
        RI_Bound = arcpy.Parameter(name="RI_Boundary",
                                       displayName="RI_Boundary",
                                       datatype="DEFeatureClass",
                                       parameterType="Required",  # Required|Optional|Derived
                                       direction="Input",  # Input|Output
                                       )

        params2.append(RI_Bound)

#for clip parameter 2
        Directory2 = arcpy.Parameter(name="Input_Directory",
                                       displayName="Input Directory",
                                       datatype="DEWorkspace",
                                       parameterType="Required",  # Required|Optional|Derived
                                       direction="Input",  # Input|Output
                                       )
        params2.append(Directory2)

        return params2

#Don't touch below
    def isLicensed(self):
            """Set whether tool is licensed to execute."""
            return True

    def updateParameters(self, parameters):
            """Modify the values and properties of parameters before internal
            validation is performed.  This method is called whenever a parameter
            has been changed."""  # can provide a warning if the wrong data
            return

    def updateMessages(self, parameters):
            """Modify the messages created by internal validation for each tool
            parameter.  This method is called after internal validation."""
            return

#Dont Touch above.

    def execute(self, parameters, messages):
        """The source code of the tool."""

        import os

        input_SHP = parameters[0].valueAsText
        RI_Bound = parameters[1].valueAsText
        Directory2 = parameters[2].valueAsText

#Process: Clip
        arcpy.Clip_analysis(input_SHP, RI_Bound, os.path.join(Directory2, "Site_Buffer_clip"), "")


        return

# ###############################SplitbyAttributeTool###########################################################

class SplitbyAttributeTool(object):
    def __init__(self):
         """Define the tool (tool name is the name of the class)."""
         self.label = "SplitbyAttributeTool"  # name of the tool
         self.description = "This tool takes the SHP file, Site_Buffer_clip, and splits by desired attributes"  # description or label of tool
         self.canRunInBackground = False  # background geoprocessing, you can do things while it is running
            # most the time it is true but false if you dont want other stuff running

    def getParameterInfo(self):
        """Define parameter definitions"""
        params3 = []

#for split parameter 0
        Site_Buffer_clip = arcpy.Parameter(name="Site_Buffer_clip",
                                       displayName="Site Buffer Clip",
                                       datatype="DEFeatureClass",
                                       parameterType="Required",  # Required|Optional|Derived
                                       direction="Input",  # Input|Output
                                       )
        params3.append(Site_Buffer_clip)

#for split parameter 1
        Directory3 = arcpy.Parameter(name="Input_Directory",
                                       displayName="Input Directory",
                                       datatype="DEWorkspace",
                                       parameterType="Required",  # Required|Optional|Derived
                                       direction="Input",  # Input|Output
                                       )
        params3.append(Directory3)

        return params3

# Don't touch below
    def isLicensed(self):
        """Set whether tool is licensed to execute."""
        return True

    def updateParameters(self, parameters):
        """Modify the values and properties of parameters before internal
        validation is performed.  This method is called whenever a parameter
        has been changed."""  # can provide a warning if the wrong data
        return

    def updateMessages(self, parameters):
        """Modify the messages created by internal validation for each tool
        parameter.  This method is called after internal validation."""
        return

# Don't touch above

    def execute(self, parameters, messages):
        """The source code of the tool."""


        Site_Buffer_clip = parameters[0].valueAsText
        Directory3 = parameters[1].valueAsText


#Process: Slit by attributes
        arcpy.SplitByAttributes_analysis(Site_Buffer_clip, Directory3, ['WS_Venue'])


        return



# ALL DONE!